

var tables = [
    {
        "number1" : "2",
        "number2":  "0",
        "answer": "0",
        "speech": "2 multiplied by 0 is equal to 0"
    },
    {
        "number1" : "2",
        "number2":  "0",
        "answer": "0",
        "speech": "2 multiplied by 0 is equal to 0"
    },
    {
        "number1" : "2",
        "number2":  "1",
        "answer": "2",
        "speech": "2 multiplied by 1 is equal to 2"
    },
    {
        "number1" : "2",
        "number2":  "2",
        "answer": "4",
        "speech": "2 multiplied by 2 is equal to 4"
    },
    
    {
        "number1" : "2",
        "number2":  "3",
        "answer": "6",
        "speech": "2 multiplied by 3 is equal to 6"
    },
    {
        "number1" : "2",
        "number2":  "4",
        "answer": "8",
        "speech": "2 multiplied by 4 is equal to 8"
    },
    {
        "number1" : "2",
        "number2":  "5",
        "answer": "10",
        "speech": "2 multiplied by 5 is equal to 10"
    },
    {
        "number1" : "2",
        "number2":  "6",
        "answer": "12",
        "speech": "2 multiplied by 6 is equal to 12"
    },
    {
        "number1" : "2",
        "number2":  "7",
        "answer": "14",
        "speech": "2 multiplied by 7 is equal to 14"
    },
    {
        "number1" : "2",
        "number2":  "8",
        "answer": "16",
        "speech": "2 multiplied by 8 is equal to 16"
    },
    {
        "number1" : "2",
        "number2":  "9",
        "answer": "18",
        "speech": "2 multiplied by 9 is equal to 18"
    },
    {
        "number1" : "2",
        "number2":  "10",
        "answer": "20",
        "speech": "2 multiplied by 10 is equal to 20"
    },
    {
        "number1" : "2",
        "number2":  "11",
        "answer": "22",
        "speech": "2 multiplied by 11 is equal to 22"
    },
    {
        "number1" : "2",
        "number2":  "12",
        "answer": "24",
        "speech": "2 multiplied by 12 is equal to 24"
    }
    
        
]