var tables = [
    {
        'question' : '2*0',
        "option1" : "2",
        "option2":  "0",
        "option3":  "20",
        "answer": "2",
        "correct": "2*0 = 0",
        "speech": "2 multiplied by 0 is equal to 0"
    },
    {
        'question' : '2*1',
        "option1" : "2",
        "option2":  "1",
        "option3":  "3",
        "answer": "1",
        "correct": "2*1 = 2",
        "speech": "2 multiplied by 1 is equal to 2"
    },
    {
        'question' : '2*2',
        "option1" : "9",
        "option2":  "6",
        "option3":  "4",
        "answer": "3",
        "correct": "2*2 = 4",
        "speech": "2 multiplied by 2 is equal to 4"
    },
    {
        'question' : '2*3',
        "option1" : "1",
        "option2":  "6",
        "option3":  "2",
        "answer": "2",
        "correct": "2*3 = 6",
        "speech": "2 multiplied by 3 is equal to 6"
    },
    {
        'question' : '2*4',
        "option1" : "8",
        "option2":  "6",
        "option3":  "18",
        "answer": "1",
        "correct": "2*4 = 8",
        "speech": "2 multiplied by 4 is equal to 8"
    },
    {
        'question' : '2*5',
        "option1" : "2",
        "option2":  "10",
        "option3":  "20",
        "answer": "2",
        "correct": "2*5 = 10",
        "speech": "2 multiplied by 5 is equal to 10"
    },
    {
        'question' : '2*6',
        "option1" : "12",
        "option2":  "8",
        "option3":  "20",
        "answer": "1",
        "correct": "2*6 = 12",
        "speech": "2 multiplied by 6 is equal to 12"
    },
    {
        'question' : '2*7',
        "option1" : "12",
        "option2":  "8",
        "option3":  "14",
        "answer": "3",
        "correct": "2*7 = 14",
        "speech": "2 multiplied by 7 is equal to 14"
    },
    {
        'question' : '2*8',
        "option1" : "12",
        "option2":  "16",
        "option3":  "2",
        "answer": "2",
        "correct": "2*8 = 16",
        "speech": "2 multiplied by 8 is equal to 16"
    },
    {
        'question' : '2*9',
        "option1" : "12",
        "option2":  "8",
        "option3":  "18",
        "answer": "3",
        "correct": "2*9 = 18",
        "speech": "2 multiplied by 9 is equal to 18"
    },
    {
        'question' : '2*10',
        "option1" : "20",
        "option2":  "19",
        "option3":  "10",
        "answer": "1",
        "correct": "2*10 = 20",
        "speech": "2 multiplied by 10 is equal to 20"
    },

]